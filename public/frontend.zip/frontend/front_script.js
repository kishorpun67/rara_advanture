// alert('test')

$('.qtyMinus').click(function(){
    if($(this).hasClass('qtyMinus')){
        var cart_id = $(this).attr('attr');
        var qty = "qtyMinus"
        // alert(qty)
        $.ajax({
            type: 'post',
            url: 'update-cart-item-quantity',
            data: {
                cart_id: cart_id,
                qty: qty,
            },
            success: function(response) {
                // alert(response)
                $('#appendCartItem').html(response.view);
            },
            error: function() {
                alert("Error");
            }
        });
    }
})
$('.qtyPlus').click(function(){
    if($(this).hasClass('qtyPlus')){
        var cart_id = $(this).attr('attr');
        var qty = "qtyPlus"
        $.ajax({
            type: 'post',
            url: 'update-cart-item-quantity',
            data: {
                cart_id: cart_id,
                qty: qty,
            },
            success: function(response) {
                // alert(response)
                $('#appendCartItem').html(response.view);
            },
            error: function() {
                alert("Error");
            }
        });
    }
})

$(".call-waiter").click(function(){
    $.ajax({
        type: 'post',
        url: '/call-waiter',
        data: {
            
        },
        success: function(response) {
            // alert(response)
            if(response=="success"){
                alert('Waiter arrived in few minutes')
            }
            // $('#appendCartItem').html(response.view);
        },
        error: function() {
            alert("Error");
        }
    });})